import React from 'react';
import Titulo from '../Titulo/Titulo.js';
//import { Link } from 'react-router-dom';
import './Missao.css'

export default function Missao() {
    return (
        <>
            <Titulo texto="Sessão de Missão!" />
            <div className="missao">
                
            </div>
        </>
    )
}