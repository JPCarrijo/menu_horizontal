import React from 'react';
import Titulo from '../Titulo/Titulo.js';
//import { Link } from 'react-router-dom';
import './Parceiros.css'

export default function Parceiros() {
    return (
        <>
            <Titulo texto="Sessão de Parceiros!" />
            <div className="parceiros">
                
            </div>
        </>
    )
}