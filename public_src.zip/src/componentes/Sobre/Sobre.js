import React from 'react';
import Titulo from '../Titulo/Titulo.js';
//import { Link } from 'react-router-dom';
import './Sobre.css'

export default function Sobre() {
    return (
        <>
            <Titulo texto="Sessão de Sobre!" />
            <div className="sobre">
                
            </div>
        </>
    )
}