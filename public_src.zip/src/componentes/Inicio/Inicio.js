import React from 'react';
import Titulo from '../Titulo/Titulo.js';
//import { Link } from 'react-router-dom';
import './Inicio.css'

export default function Inicio() {
    return (
        <>
            <Titulo texto="Formulário inicial do projeto!" />
            <div className="inicio">
                
            </div>
        </>
    )
}