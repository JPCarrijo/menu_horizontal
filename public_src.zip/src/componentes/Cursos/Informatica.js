import React from 'react';
import Titulo from '../Titulo/Titulo';
//import { Link } from 'react-router-dom';
import './Informatica.css';

export default function Informatica() {
    return (
        <>
            <Titulo texto="Sessão de Informática!" />
            <div className="informatica">
                
            </div>
        </>
    )
}