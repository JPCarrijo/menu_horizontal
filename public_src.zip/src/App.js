import '../src/componentes/App.css';
import React from 'react';
import Secoes from './Secoes'

function App() {
  return (
    <>
        <Secoes />
    </>
  );
}

export default App;
/*
  Seções:
    1 - início
    2 - cursos
    3 - contatos
    4 - parceiros
    5 - missão
    6 - rodapé - footer
*/